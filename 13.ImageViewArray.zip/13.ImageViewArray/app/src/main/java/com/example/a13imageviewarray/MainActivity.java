package com.example.a13imageviewarray;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private int[] imgID = {R.drawable.i , R.drawable.ii , R.drawable.iii , R.drawable.iv , R.drawable.v ,
                            R.drawable.vi , R.drawable.vii , R.drawable.viii , R.drawable.ix , R.drawable.x };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button)findViewById(R.id.button);
        EditText input = (EditText)findViewById(R.id.editTextTextPersonName);
    }

    public void button(View view) {
        EditText input = (EditText)findViewById(R.id.editTextTextPersonName);
        ImageView image = (ImageView)findViewById(R.id.imageView);
        int n = Integer.parseInt(input.getText().toString());
        image.setImageResource(imgID[n-1]);
    }
}